﻿namespace PowerNutrition.Web.ViewModels.Cart
{
    public class AllCartItemsViewmodel
    {
        public string Id { get; set; } = null!;

        public string Name { get; set; } = null!;

        public string Price { get; set; } = null!;

        public string Amount { get; set; } = null!;

        public string ImageUrl { get; set; } = null!;
    }
}
