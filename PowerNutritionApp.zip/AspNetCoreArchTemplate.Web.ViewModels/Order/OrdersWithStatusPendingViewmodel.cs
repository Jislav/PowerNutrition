﻿namespace PowerNutrition.Web.ViewModels.Order
{
    public class OrdersWithStatusPendingViewmodel : UserOrderHistoryViewmodel
    {

    }
}
