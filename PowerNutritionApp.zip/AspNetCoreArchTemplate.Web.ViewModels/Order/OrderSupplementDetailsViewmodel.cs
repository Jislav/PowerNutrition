﻿

namespace PowerNutrition.Web.ViewModels.Order
{
    public class OrderSupplementDetailsViewmodel
    {
        public string Name { get; set; } = null!;

        public string Brand { get; set; } = null!;

        public string ImageUrl { get; set; } = null!;

        public string TotalPrice { get; set; } = null!;
    }
}
