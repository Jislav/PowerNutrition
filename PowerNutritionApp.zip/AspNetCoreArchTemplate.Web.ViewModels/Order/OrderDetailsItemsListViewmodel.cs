﻿namespace PowerNutrition.Web.ViewModels.Order
{
    public class OrderDetailsItemsListViewmodel
    {
        public string Name { get; set; } = null!;

        public string Quantity { get; set; } = null!;

        public string Price { get; set; } = null!;

        public string ImageUrl { get; set; } = null!;
    }
}
