﻿namespace PowerNutrition.Web.ViewModels.Manage
{
    public class AllSupplemenetsEditViewmodel : AllSupplementsDeleteViewmodel
    {

    }
}
