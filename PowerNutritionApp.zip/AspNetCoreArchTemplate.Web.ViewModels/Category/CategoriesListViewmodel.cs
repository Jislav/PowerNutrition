﻿namespace PowerNutrition.Web.ViewModels.Category
{
    public class CategoriesListViewmodel
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!;
    }
}
