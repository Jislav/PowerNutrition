﻿namespace PowerNutrition.Web.ViewModels.Category
{
    public class CategoryDeleteInputModel : CategoriesListViewmodel
    {

    }
}
