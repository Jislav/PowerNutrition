﻿namespace PowerNutrition.Web.ViewModels.Supplement
{
    public class SupplementEditInputModel : AddSupplementInputModel
    {
        public string Id { get; set; } = null!;
    }
}
